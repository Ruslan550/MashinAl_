﻿using System.Windows.Controls;
namespace MashinAl.Views;
public partial class GuestMainPageCarPostsView : Page
{
    public GuestMainPageCarPostsView()
    {
        InitializeComponent();
    }
}
