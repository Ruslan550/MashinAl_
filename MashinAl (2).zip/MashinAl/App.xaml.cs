﻿using System.Windows;
namespace MashinAl;
public partial class App : Application{}
