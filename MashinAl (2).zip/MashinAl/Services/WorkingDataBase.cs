﻿using MashinAl.Models;
using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using System.Windows;

namespace MashinAl.Services {
    public static class WorkingDataBase
    {

        public static ObservableCollection<Admin>? Admins { get; set; }
        public static ObservableCollection<Car>? Cars { get; set; }

        public static ObservableCollection<User>? Users { get; set; }

        readonly static string adminsJson = "../../../../MashinAl/DataBase/Admins.json";
        readonly static string usersJson = "../../../../MashinAl/DataBase/Users.json";
        readonly static string carsJson = "../../../../MashinAl/DataBase/Cars.json";



        public static Admin AdminAuthentication(string username, string password)
        {
            Admins = JsonSerializer.Deserialize<ObservableCollection<Admin>>(File.ReadAllText(adminsJson));

            for (int i = 0; i < Admins?.Count; i++)
            {
                if (username == Admins[i].Username && password == Admins[i].Password)
                    return Admins[i];
            }
            return null!;
        }

        public static void AddUserToDataBase(User? user)
        {
            Users = JsonSerializer.Deserialize<ObservableCollection<User>>(File.ReadAllText(usersJson));
            Users?.Add(user!);
            File.WriteAllText(usersJson, JsonSerializer.Serialize(Users));
        }
    }
}
