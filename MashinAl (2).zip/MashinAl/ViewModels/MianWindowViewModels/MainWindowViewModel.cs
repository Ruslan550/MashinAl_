﻿using MashinAl.Commands;
using MashinAl.ViewModels.PageViewModels;
using MashinAl.Views;
using MashinAl.Views.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Navigation;

namespace MashinAl.ViewModels.WindowViewModels
{
    internal class MainWindowViewModel
    {
        private ICommand? _exitCommand;
        private ICommand? _adminCommand;
        private ICommand? _guestCommand;
        private GuestMainModel? _nextPageGuest;

        public ICommand? ExitCommand
        {
            get => _exitCommand;
            set
            {
                if (_exitCommand != value)
                {
                    _exitCommand = value;
                  
                }
            }
        }

        public ICommand? AdminCommand
        {
            get => _adminCommand;
            set
            {
                if (_adminCommand != value)
                {
                    _adminCommand = value ;
                }
            }
        }

        public ICommand? GuestCommand
        {
            get => _guestCommand;
            set
            {
                if (_guestCommand != value)
                {
                    _guestCommand = value;
                    
                }
            }
        }

        public GuestMainModel? NextPageGuest
        {
            get => _nextPageGuest;
            set
            {
                if (_nextPageGuest != value)
                {
                    _nextPageGuest = value;
                  
                }
            }
        }


        public void GuestPage(object? param)
        {
            MainWindowView? mainWindowView = null;
            if (param is NavigationWindow NavigationWindows)
                mainWindowView = NavigationWindows as MainWindowView;

            NextPageGuest = new GuestMainModel();
            NextPageGuest.DataContext = new GuestMainModel();
            mainWindowView!.Navigate(NextPageGuest);
        }
        public void Exit(object? param)
        {
            if (param is NavigationWindow mainWindowView)
                mainWindowView.Close();
        }
        public MainWindowViewModel()
        {
            ExitCommand = new RelayCommand(Exit);
            GuestCommand = new RelayCommand(GuestPage);
        }

       

      
    }
}