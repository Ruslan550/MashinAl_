﻿using MashinAl.Services;
using System.Collections.Generic;
using System.Windows.Documents;

namespace MashinAl.Models
{
    public class Car : NotificationService
    {
        private string? mark;
        private string? model;
        private string? color;
        private int? year;
        private int? price;
        private string? gearbox;
        private string? ban_type;
        private string? transmitter;
        private string? condition;
        private int? probeg;
        private string? city;
        private bool isCredit;
        private bool isBarter;
        private User? carsOwner;
        private List<string>? image_pathes_of_car;

        public string? Mark
        {
            get => mark;
            set
            {
                mark = value;
                OnPropertyChanged();
            }
        }

        public string? Model
        {
            get => model;
            set
            {
                model = value;
                OnPropertyChanged();
            }
        }

        public string? Color
        {
            get => color;
            set
            {
                color = value;
                OnPropertyChanged();
            }
        }

        public int? Year
        {
            get => year;
            set
            {
                year = value;
                OnPropertyChanged();
            }
        }

        public int? Price
        {
            get => price;
            set
            {
                price = value;
                OnPropertyChanged();
            }
        }

        public string? Gearbox
        {
            get => gearbox;
            set
            {
                gearbox = value;
                OnPropertyChanged();
            }
        }

        public string? Ban_type
        {
            get => ban_type;
            set
            {
                ban_type = value;
                OnPropertyChanged();
            }
        }

        public string? Transmitter
        {
            get => transmitter;
            set
            {
                transmitter = value;
                OnPropertyChanged();
            }
        }

        public string? Condition
        {
            get => condition;
            set
            {
                condition = value;
                OnPropertyChanged();
            }
        }

        public int? Probeg
        {
            get => probeg;
            set
            {
                probeg = value;
                OnPropertyChanged();
            }
        }

        public string? City
        {
            get => city;
            set
            {
                city = value;
                OnPropertyChanged();
            }
        }

        public bool IsCredit
        {
            get => isCredit;
            set
            {
                isCredit = value;
                OnPropertyChanged();
            }
        }

        public bool IsBarter
        {
            get => isBarter;
            set
            {
                isBarter = value;
                OnPropertyChanged();
            }
        }

        public User? CarsOwner
        {
            get => carsOwner;
            set
            {
                carsOwner = value;
                OnPropertyChanged();
            }
        }

        public List<string>? ImagePathesOfCar
        {
            get => image_pathes_of_car;
            set
            {
                image_pathes_of_car = value;
                OnPropertyChanged();
            }
        }

        public Car(string? mark, string? model, string? color,
            int? year, int? price, string? gearbox, string? ban_type,
            string? transmitter, string? condition, int? probeg, string? city,
            bool isCredit, bool isBarter, User? carsOwner, List<string>? image_pathes_of_car)
        {
            Mark = mark;
            Model = model;
            Color = color;
            Year = year;
            Price = price;
            Gearbox = gearbox;
            Ban_type = ban_type;
            Transmitter = transmitter;
            Condition = condition;
            Probeg = probeg;
            City = city;
            IsCredit = isCredit;
            IsBarter = isBarter;
            CarsOwner = carsOwner;
            ImagePathesOfCar = image_pathes_of_car;
        }

        public Car() { }
    }
}
