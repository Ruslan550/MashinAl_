﻿using MashinAl.Services;
using System.Collections.ObjectModel;

namespace MashinAl.Models
{
    public class User : NotificationService
    {
        private string? gmail;
        private ObservableCollection<Car>? usersCars;

        public string? Gmail
        {
            get => gmail;
            set
            {
                Gmail = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<Car>? UsersCars
        {
            get => usersCars;
            set
            {
                usersCars = value;
                OnPropertyChanged();
            }
        }

        public void AddCarToUser(Car? car)
        {
            if (UsersCars == null) UsersCars = new ObservableCollection<Car>() { };
            UsersCars.Add(car!);
        }

        public void AddUserToDataBase() => WorkingDataBase.AddUserToDataBase(this);
    }
}
