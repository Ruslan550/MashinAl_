﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace MashinAl.Services
{
    public abstract class NotificationService : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string? NotifactionName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(NotifactionName));
        }
    }
}
