﻿using MashinAl.Commands;
using MashinAl.Services;
using System.Windows.Controls;
using System.Windows.Input;

namespace MashinAl.ViewModels.PageViewModels
{
    internal class GuestMainModel : NotificationService
    {
        private ICommand? _backCommand;

        public ICommand? BackCommand
        {
            get => _backCommand;
            set
            {
                if (_backCommand != value)
                {
                    _backCommand = value;
                    OnPropertyChanged();
                }
            }
        }

        public GuestMainModel DataContext { get; set; }

        public GuestMainModel()
        {
            BackCommand = new RelayCommand(Back);
        }

        public void Back(object? item)
        {
            if (item is Page page)
            {
                page.NavigationService.GoBack();
            }
        }
    }
}

