﻿using MashinAl.Services;

namespace MashinAl.Models
{
    public class Admin : NotificationService
    {
        private string? username;
        private string? email;
        private string? password;

        public string? Username
        {
            get => username;
            set
            {
                username = value;
                OnPropertyChanged();
            }
        }

        public string? Email
        {
            get => email;
            set
            {
                email = value;
                OnPropertyChanged();
            }
        }

        public string? Password
        {
            get => password;
            set
            {
                password = value;
                OnPropertyChanged();
            }
        }

        public Admin(string? username, string? password, string? email)
        {
            Username = username;
            Password = password;
            Email = email;
        }

       
        public Admin() {
        }
    }
}

