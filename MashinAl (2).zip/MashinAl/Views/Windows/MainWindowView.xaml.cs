﻿using MashinAl.ViewModels.WindowViewModels;
using System.Windows.Navigation;
namespace MashinAl.Views.Windows;
public partial class MainWindowView : NavigationWindow
{
    public MainWindowView()
    {
        InitializeComponent();
        DataContext = new MainWindowViewModel();
    }

    private void Button_Click(object sender, System.Windows.RoutedEventArgs e)
    {

    }
}
